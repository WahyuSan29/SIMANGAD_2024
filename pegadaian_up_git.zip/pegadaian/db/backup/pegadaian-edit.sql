-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 30, 2023 at 10:11 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pegadaian`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nama_admin` varchar(30) NOT NULL,
  `username` varchar(10) NOT NULL,
  `pass` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama_admin`, `username`, `pass`) VALUES
(1, 'Wahyu', 'wahyu123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL,
  `id_jenis` int(11) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama_barang` varchar(30) NOT NULL,
  `merk` varchar(20) NOT NULL,
  `tahun` varchar(5) NOT NULL,
  `warna` varchar(29) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `id_jenis`, `nik`, `nama_barang`, `merk`, `tahun`, `warna`) VALUES
(1, 2, '6202052907000004', 'HP', 'Iphone 11', '2020', 'Gold'),
(2, 2, '6202052907000004', 'HP', 'Iphone 11', '2020', 'Gold'),
(3, 1, '6202052907000004', 'Emas 2 gram', '', '', ''),
(4, 2, '6202052907000004', 'HP', 'Iphone 11', '2020', 'Gold'),
(5, 2, '6202052907000004', 'HP', 'Iphone 12', '2020', 'Gold'),
(6, 2, '6202052907000004', 'HP', 'Iphone 11', '2020', 'Gold'),
(7, 1, '6202052907000004', 'HP', 'Iphone 11', '2020', 'Gold'),
(8, 2, '6202052907000004', 'HP', 'Iphone 11', '2020', 'Gold'),
(9, 2, '6202052907000004', 'Handphone', 'Xiaomi', '2023', 'Hitam'),
(10, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(11, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(12, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Blackk'),
(13, 2, '6202052907000004', 'Handphone', 'Xiamoi', '2010', 'Blackk'),
(14, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(15, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(16, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(17, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(18, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(19, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(20, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(21, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(22, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(23, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(24, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(25, 2, '6202052907000004', 'Handphone', 'Xiamo', '2010', 'Black'),
(26, 2, '575682353467', 'Handphone', 'Xiamo', '2010', 'Black'),
(27, 2, '5', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `besar_pinjaman`
--

CREATE TABLE `besar_pinjaman` (
  `id_bsr_pinjaman` int(11) NOT NULL,
  `golongan` varchar(3) NOT NULL,
  `minimal` float NOT NULL,
  `maksimal` float NOT NULL,
  `tarif_ujroh` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `besar_pinjaman`
--

INSERT INTO `besar_pinjaman` (`id_bsr_pinjaman`, `golongan`, `minimal`, `maksimal`, `tarif_ujroh`) VALUES
(1, 'A', 50000, 500000, 1),
(2, 'B1', 550000, 1000000, 1.5),
(3, 'B2', 1050000, 2500000, 2),
(4, 'B3', 2550000, 5000000, 2),
(5, 'C', 5000000, 10000000, 2.5);

-- --------------------------------------------------------

--
-- Table structure for table `jenis_barang`
--

CREATE TABLE `jenis_barang` (
  `id_jenis` int(11) NOT NULL,
  `jenis_barang` varchar(10) NOT NULL,
  `persen_taksiran` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jenis_barang`
--

INSERT INTO `jenis_barang` (`id_jenis`, `jenis_barang`, `persen_taksiran`) VALUES
(1, 'Emas', 90),
(2, 'Handphone', 70);

-- --------------------------------------------------------

--
-- Table structure for table `nasabah`
--

CREATE TABLE `nasabah` (
  `nik` varchar(16) NOT NULL,
  `nama_nasabah` varchar(30) NOT NULL,
  `alamat_nasabah` varchar(30) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jk` char(9) NOT NULL,
  `pekerjaan` varchar(20) NOT NULL,
  `no_hp` varchar(13) NOT NULL,
  `nama_keluarga` varchar(30) NOT NULL,
  `alamat_keluarga` varchar(30) NOT NULL,
  `no_hp_keluarga` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nasabah`
--

INSERT INTO `nasabah` (`nik`, `nama_nasabah`, `alamat_nasabah`, `tgl_lahir`, `jk`, `pekerjaan`, `no_hp`, `nama_keluarga`, `alamat_keluarga`, `no_hp_keluarga`) VALUES
('6202052907000004', 'Palui', 'Jl.Batu Berlian', '2001-04-11', 'Laki-Laki', 'Swasta', '082245093883', 'Tomy', 'Jl.Batu Berlian', '082245093883'),
('62080529070003', 'Wahyu', 'Jl. RA. Kartinii', '2023-07-06', 'Laki-laki', 'Swasta', '081345178078', 'Syam', 'Jl. Muchran Ali', '087819201105');

-- --------------------------------------------------------

--
-- Table structure for table `pengelola`
--

CREATE TABLE `pengelola` (
  `nik_pengelola` varchar(20) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `alamat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengelola`
--

INSERT INTO `pengelola` (`nik_pengelola`, `nama`, `alamat`) VALUES
('6202051511720003', 'Budi Sulistiono, S.Pd', 'Jalan Bukit Raya V No.25');

-- --------------------------------------------------------

--
-- Table structure for table `penggadaian`
--

CREATE TABLE `penggadaian` (
  `id_surat` int(11) NOT NULL,
  `no_surat` varchar(30) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nik_pengelola` varchar(20) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `harga_taksir` float NOT NULL,
  `harga_sewa` float NOT NULL,
  `tgl_gadai` date NOT NULL,
  `lama_gadai` int(11) NOT NULL,
  `keterangan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penggadaian`
--

INSERT INTO `penggadaian` (`id_surat`, `no_surat`, `nik`, `nik_pengelola`, `id_barang`, `harga_taksir`, `harga_sewa`, `tgl_gadai`, `lama_gadai`, `keterangan`) VALUES
(1, '1/BMT071/SPG/VI/2023', '6202052907000004', '6202051511720003', 4, 1200000, 102000, '2023-06-23', 2, 'Lunas'),
(2, '2/BMT071/SPG/VI/2023', '6202052907000004', '6202051511720003', 5, 1000000, 33000, '2023-06-23', 1, 'Lunas'),
(3, '3/BMT071/SPG/VI/2023', '6202052907000004', '6202051511720003', 6, 1000000, 66000, '2023-06-23', 2, 'Lunas'),
(4, '4/BMT071/SPG/VI/2023', '6202052907000004', '6202051511720003', 7, 120, 132000, '2023-06-23', 2, 'Lunas'),
(5, '5/BMT071/SPG/VI/2023', '6202052907000004', '6202051511720003', 8, 1200000, 102000, '2023-06-23', 2, 'Lunas'),
(6, '6/BMT071/SPG/VI/2023', '6202052907000004', '6202051511720003', 1, 1200000, 51000, '2023-06-23', 1, 'Belum Lunas'),
(7, '7/BMT071/SPG/VI/2023', '6202052907000004', '6202051511720003', 9, 1000000, 33000, '2023-06-26', 1, 'Belum Lunas'),
(8, '8/BMT071/SPG/VI/2023', '6202052907000004', '6202051511720003', 10, 1100000, 45000, '2023-06-26', 1, 'Belum Lunas'),
(9, '9/BMT071/SPG/VI/2023', '6202052907000004', '6202051511720003', 11, 700000, 33000, '2023-06-27', 1, 'Belum Lunas'),
(10, '10/BMT071/SPG/VI/2023', '6202052907000004', '6202051511720003', 25, 700000, 33000, '2023-07-01', 1, 'Belum Lunas');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `besar_pinjaman`
--
ALTER TABLE `besar_pinjaman`
  ADD PRIMARY KEY (`id_bsr_pinjaman`);

--
-- Indexes for table `jenis_barang`
--
ALTER TABLE `jenis_barang`
  ADD PRIMARY KEY (`id_jenis`);

--
-- Indexes for table `nasabah`
--
ALTER TABLE `nasabah`
  ADD PRIMARY KEY (`nik`);

--
-- Indexes for table `pengelola`
--
ALTER TABLE `pengelola`
  ADD PRIMARY KEY (`nik_pengelola`);

--
-- Indexes for table `penggadaian`
--
ALTER TABLE `penggadaian`
  ADD PRIMARY KEY (`id_surat`),
  ADD UNIQUE KEY `no_surat` (`no_surat`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `besar_pinjaman`
--
ALTER TABLE `besar_pinjaman`
  MODIFY `id_bsr_pinjaman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jenis_barang`
--
ALTER TABLE `jenis_barang`
  MODIFY `id_jenis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
