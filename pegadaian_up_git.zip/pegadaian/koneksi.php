<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'pegadaian';

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname) or die('koneksi gagal');
