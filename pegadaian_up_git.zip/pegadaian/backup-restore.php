<?php include 'check_login.php'; ?>

<div class="container">
	<div class="row">
		<div class="col-md-3 mt-5">
			<div class="card" style="width: 14rem;">
				<img src="Gambar/backup.png" class="card-img-top" height="200" width="300" alt="Backup Icon">
				<div class="card-body text-center">
					<p class="card-title">Backup Data?</p>
					<a href="index.php?page=backup" class="btn btn-primary text-center">PILIH</a>
				</div>
			</div>
		</div>
		<!-- <div class="col-md-2">
			<div class="card" style="width: 10rem;">
				<div class="card-body" align="center">
					<p class="card-title">Restore Data?</p>
					<a href="index.php?page=restore" class="btn btn-primary text-center">OKE</a>
				</div>

			</div>

		</div> -->



	</div>
</div>